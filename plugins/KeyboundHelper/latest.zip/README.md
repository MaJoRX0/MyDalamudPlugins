# Keybound Helper

Experimental Dalamud API 15 plugin that reads enemy words and submits them through Keybound Brawler's text input. Open `/keybound`.

## Version 0.1.17

Closest matching now considers targetable battle NPCs beyond the two enemy types in the original Airbuster recordings. Version 0.1.16's positive allowlist prevented other enemy types from being matched at all. The known stationary helper types remain excluded, and visibility, geometry, ambiguity, unique association, and temporal confirmation checks still apply. New enemy types are not automatically assigned a word just because they are nearby.

Under **Show debugging**, unmatched words now show a reason instead of an empty distance list: missing enemy objects, label offset, overlapping enemies, missing geometry, or pending confirmation. **Copy diagnostics** and capture exports include those reasons and the latest candidate object data. The screenshot alone does not establish which check failed in that fight; a new position recording or copied diagnostics can resolve remaining failures. Replay tests still cover both original recordings, with additional checks for a previously unseen enemy type and excluded stationary actors.

## Version 0.1.16

**Prioritize closest enemies** is optional and defaults off. When both priorities are enabled, interruptible enemies come first, then distance within that group. The helper finishes the current word before choosing again. Submission spacing, retry cooldowns, and attempt caps remain in effect; an eligible closer retry can outrank a farther untried word.

Distance matching uses the scaled word-label center and projected world positions, supported by both supplied five-second recordings. Only the observed moving-enemy type (BaseId 19826) and Airbuster (19596) currently qualify. Nearby stationary actors, untargetable remnants, offscreen objects, hidden/empty words, duplicate fields, and ambiguous correspondences are excluded. A word/object pairing must persist for at least 100 ms, with no observation gap over 500 ms. Matches are recomputed and removed immediately when their evidence disappears. This is a conservative geometric association, not a native word-to-object link; other enemy types use normal scheduling until captured and validated.

Within each interrupt-priority group, distance ordering applies only when every eligible word has a reliable distance. Otherwise that group falls back to its normal untried-first/oldest-retry order, avoiding an assumption that unmatched enemies are far away. **Show debugging** displays the current matches and distances; **Copy diagnostics** includes matched object IDs and horizontal error. Position recording remains available. Tests replay all 42 supplied frames and cover ambiguous matches, changed words, excluded actors, ordering, both toggles, and timing limits. Live in-game confirmation is still needed.

## Version 0.1.15

**Prioritize interruptible enemies** is optional and defaults off. When choosing the next word, a visible numeric counter and visible spell label in the corresponding `KTGEnemyCastBar` slot grant priority. Hidden counters, missing/empty words, ambiguous fields, and visible interruption messages do not qualify. The current word is finished normally. Submission intervals, retry delays, and attempt limits still apply; eligible interruptible retries outrank ordinary untried words. Replay checks cover the supplied boss and regular-enemy captures. Slot correspondence is based on the matching observed UI paths and still needs in-game validation.

Under **Show debugging**, click **Record positions (5s)** during combat. It records up to 21 frames, approximately 250 ms apart, without stopping typing, and automatically saves `keybound-position-*.json` in the plugin configuration folder. **Copy position file path** copies the saved path. Record while several enemies approach and send that file for analysis. Leaving the fight saves a partial recording.

Frames include word/cast/player-label/HP-interface geometry (including non-text nodes), local-player world position, and up to 512 non-player objects with IDs, world coordinates, projected screen points, center distances, hitbox radii, and ordinary casting fields when available. This is diagnostic only: UI slots are not object IDs, and minigame enemies may not appear in the ordinary object table. Screen position alone does not establish world distance. No closest-enemy targeting is enabled. The recording includes player-name labels but excludes chat interfaces.

## Version 0.1.14

Preserved-case words now activate an idle text editor before attempting an initial capital letter. The 0.1.13 trace shows an empty field timing out with navigation focus present but text input inactive. The helper uses one temporary lowercase letter, confirms it, removes it with Ctrl+A/Backspace, and then starts the original word. Initial Unicode characters and punctuation use the same preparation; ordinary lowercase and digit starts keep their existing path. Preparation does not advance or change the word's typing plan and is bounded to one attempt until another lockout or a new word.

Regression checks replay the supplied focus state and simulate an editor that ignores Shift+letter until activated. Actual in-game confirmation is still needed.

## Version 0.1.13

The main window is compact: current status and submission count, Start/Stop, automation toggles, **Type in lowercase**, timing variation, and the between-word interval. Detailed speed/error/retry controls are under **Timing and retries**. **Show debugging** reveals captures, exports, diagnostics, a one-word test, live words, and a read-only interface viewer; it starts unchecked.

**Type in lowercase** defaults on to preserve existing behavior. Switch it off to match the enemy's capitalization, including accented capitals. Changes apply to the next word. Intentional typos retain the replaced letter's case. Built-in mapping and keyboard input are always enabled; the old switches and editable manual mapping are removed. Saved configurations that previously disabled either mode now resolve to enabled.

## Version 0.1.12

Two independent options, both off by default, are available under the built-in mapping:

- **Auto-requeue after a completed fight:** manually enter the first fight. After the helper observes it, it can click Exit on the Keybound results screen, interact with a targetable Keybound Registrar within four yalms in territory 1360, click Register, wait for the queue, and click Commence only on a pop titled Keybound Brawler. It never moves your character. Keep the game foreground and the registrar nearby.
- **Auto-activate typing when entering Keybound:** starts the typing helper once the mapped minigame input and word layout appear, including subsequent requeued fights. Requeue can be used without auto-typing, or auto-typing without requeue.

F8, STOP, `/keybound stop`, and typing errors suspend both automatic options for the session. Use **Resume automatic options**, toggle an option, or manually start typing to resume. Resuming in the lobby still requires another manually entered first fight. Stopping automation does not withdraw a queue already registered. An unexpected return without results, a cancelled queue, or three unsuccessful button-action attempts also suspends the loop. Being in the lobby or opening the registrar after a reload never starts the first queue automatically. With auto-activate enabled, a reload in a detectable fight may start typing.

Result and registration mappings come from the supplied 10:45:49 and 10:48:14 captures. The button clicks use each button's registered click event and enabled state. Duty-pop handling uses the installed `AddonContentsFinderConfirm` title and Commence button fields; that pop was not in the supplied captures and needs live validation. Replay tests cover the full loop, independent options, no initial lobby queue, unrelated duty pops, queue cancellation, cooldowns, and session suspension. NPC interaction and all three buttons still need an in-game end-to-end test.

## Version 0.1.11

Accented words such as `Doppelgänger` now preserve the accent even when the current keyboard layout has no direct key for it. Directly mapped letters still use scan codes. Other non-ASCII characters use Unicode key-down/key-up packets instead of failing on missing mappings, dead keys, or AltGr requirements. Combining marks and surrogate pairs are delivered as a complete text element, with the same prefix confirmation and per-element typing delay. No accents are stripped, and lowercase output is preserved.

On an ASCII layout, `doppelgänger` uses ordinary keyboard presses for eleven letters and Unicode only for `ä`. Enter, Backspace, and Ctrl+A retain the existing scan-code path. Tests cover exact accented output, mixed scan-code/Unicode delivery, combining characters, and focus gating. The game's acceptance of these Unicode packets still needs live confirmation; they do not establish activity-timer behavior.

## Version 0.1.10

The new 0.1.9 trace shows the actual cleanup failure: after lockout, native navigation focus returns, but `TextActive` is false and no text-input destination is set. Ctrl+A and Backspace leave all nine characters unchanged. Cleanup now distinguishes navigation focus (which can accept a first printable letter) from an active text editor (which accepts editing shortcuts).

When cleanup finds the editor inactive, it sends one temporary lowercase `a`, confirms the resulting text, then uses Ctrl+A and one Backspace to remove both the old word and that letter. It accepts only that single-letter insertion into the owned prefix, or the single letter alone if the game reset its buffer. An ignored activation times out without repeated letters. No Enter is sent for activation. Active editors skip this extra step, and killed/replaced enemies still move on after cleanup. Regression tests include the supplied diagnostic trace and a simulated editor that ignores shortcuts until a printable key activates it. Live verification remains necessary.

## Version 0.1.9

Keyboard-mode cancellation and lockout cleanup now use Ctrl+A followed by one Backspace. The shortcut's keys are released before Backspace, and the helper waits for an empty input before continuing. Losing focus or receiving another typing lockout resets selection so the shortcut is reapplied when input is ready. Partial shortcut delivery releases accepted keys and stops. F8/Stop still stops immediately without sending new cleanup keys.

## Version 0.1.8

Typing debuffs now have an explicit recovery step. Pending keys can still be acknowledged during the lockout, but missing acknowledgments no longer time out against the disabled input. Once typing is enabled, the helper rechecks the enemy and clears its unchanged partial prefix with confirmed Backspace presses. It rebuilds the same word if that enemy remains, or selects another enemy if the slot cleared or changed while locked. A game-cleared input and a second lockout during cleanup are handled as recovery states.

The supplied 0.1.7 trace shows a seven-second lockout followed by failure on the first key after focus returns. It does not contain the actual input text, so an editing-buffer reset remains a hypothesis. Recovery rebuilds the prefix rather than trusting that the game's raw text and editing buffer survived the debuff together. Unexpected user text still stops the helper. Focus diagnostics now include recovery steps, text lengths, and pending-key match flags without copying the words themselves.

Tests replay the timing of that lockout with a simulated editor reset, a mob killed/replaced during the debuff, pending letters and Enter, and repeated lockouts. In-game confirmation is still required.

## Version 0.1.7

Wave gaps now leave automatic mode running. Temporarily missing minigame interfaces wait for the next wave, and a game-cleared partial input is reconciled before restoring focus. Exhausting an unchanged word's retry budget waits for new words instead of ending the entire run. Changed layouts and leaving the territory still stop the helper.

An already selected word continues typing and can be submitted while its label flashes invisible, as requested. Each step still checks that the same slot contains the same original word. Cleared/replaced slots cancel immediately; continuous concealment expires after eight seconds. Hidden labels cannot start a new word, and flashing does not reset the retry budget. A teammate can still defeat the enemy immediately before Enter; these checks cannot guarantee a hit.

Keyboard-mode cancellation clears an obsolete prefix with individual, acknowledged Backspace presses. It no longer mixes direct `SetText` clearing with keyboard typing, which could leave the input's internal editing state out of sync. F8, Stop, Capture, and unload stop key generation immediately and may leave a partial word in the box; delete that text manually before restarting. A failed cleanup key stops rather than blindly retrying. A confirmed wave transition can recover a cleared or unchanged pending prefix, but arbitrary unexpected text still stops the helper.

The added replay fixtures contain only the word and input interfaces from ten distinct new captures. Tests cover boss concealment, changed/empty targets, wave gaps, retry retention, cleared inputs, and acknowledged keyboard cleanup. These changes still need an in-game run through a wave change and boss fight.

## Earlier input fixes

Fixed an overly strict startup focus gate. An empty input whose own native focus node is selected can now receive its first key even when `IsTextInputActive` is false. An active text destination for another field still blocks input, and a stale matching destination without native focus is insufficient. This targets the reported state where the helper repeatedly displayed “Restoring focus” until the user typed and deleted a letter. Live verification is still needed.

**Copy focus diagnostics** copies the most recent 64 keyboard-state transitions and the current status, without typed text. Capture exports include the individual focus flags as well. If focus restoration still stalls, copy these details before manually typing so the blocked state is preserved.

Fixed a keyboard-mode state-ordering bug: a pending Enter result is now checked before focus, overlay, and enabled-state gates for new input. Previously, if submitting dropped focus, the helper could never acknowledge completion and would appear stuck after one word. Start and Submit one word now release the helper window's keyboard focus and request native focus for the mapped minigame input. Between words, lost focus is restored when no other game text box is active. Focus checks use the game's actual text-event destination instead of requiring both a component flag and a particular navigation-node hierarchy. These changes still need live validation.

Keyboard input is now enabled by default. Earlier versions directly replaced the typing-box text and invoked its Enter callback; character-by-character display did not generate letter-key events. This is a plausible explanation for defeating enemies while still being considered inactive. The reported 60-second inactivity threshold and ten-repeat-key rule have not been independently verified.

The new mode sends scan-code key-down and key-up events for letters, punctuation, spaces, and Enter through Windows `SendInput`. Each press is held for 40 ms across framework updates. Every character must appear in the game's input before the next is sent; Enter must clear the input before continuing. A 1.5-second delivery timeout stops the run instead of blindly repeating keys. This confirms input processing, not enemy damage or the game's internal inactivity state. No inactivity timer is read or patched.

Starting requests focus for the minigame typing box automatically. Input requires the game to be foreground, the exact typing component to have native keyboard focus, and no ImGui overlay to be capturing keyboard input. Other held keyboard keys pause sending; turn off Caps Lock. Keys are released on stop/unload/focus loss, and failed releases are retried while the plugin remains loaded. Keyboard mapping follows the game window's layout. As of 0.1.11, non-ASCII characters that cannot be typed directly use Unicode packets, including complete multi-code-unit text elements. Unsupported ordinary-key mappings still stop with a message.

Test **Submit one word** first, then a continuous run past two minutes. The window shows elapsed run time and key presses sent. Capture exports include input-focus state and runtime status/counts to help diagnose a repeat kick. The legacy direct-text mode remains selectable by unchecking **Send keyboard keys (letters and Enter)**; it may still fail the inactivity check.

All submitted words are lowercase, including the one-word test, retries, fixed-speed mode, and intentional typos. Lowercasing itself does not count as an error. Original enemy labels are retained internally to detect changes before submission.

Typing now progresses character by character. Defaults: 45–110 ms between characters, a separate 120–320 ms pause before Enter, and ±25% variation around the existing 800 ms between-word interval. Actual delays can be longer due to frame timing. Each delay is chosen independently, and stalled frames never cause catch-up bursts.

Automatic mode has a 3% typo chance on eligible new words, capped at 5% in settings. There must be at least 12 clean submissions before the first typo and between subsequent typos, so the overall rate is lower than the selected chance. A typo changes one ASCII letter and is submitted without correction; cleanup happens only after submission. Retries and the one-word test never deliberately make errors. Another currently visible enemy's word is excluded as a typo. Non-ASCII letters are not deliberately changed.

Set the typo chance to zero to keep varied timing without errors. Uncheck **Vary typing and submission timing** for fixed timing; keyboard mode still sends individual characters using the fastest-character setting. Legacy direct-text mode inserts the full word when variation is disabled. Settings apply to the next word. The window tracks intentional typo submissions.

If an enemy word clears or changes mid-typing, the helper clears its own unchanged partial input and chooses another. Temporary concealment preserves the already selected word as described above. If you edit the input, the helper stops and leaves your text intact. F8/Stop cancels pending typing. Lockouts and focus loss pause it without catching up afterward.

The built-in mapping comes from three in-game captures supplied on 2026-10-28. It reads all 20 enemy slots in `KTGEWord` and the typing box in `KTGInput`, in territory 1359. No manual field selection is needed. It preserves punctuation and spaces, ignores hidden/empty labels, and pauses during the game's temporary typing lockout. The third capture contains this lockout with five enemy words still visible.

**Validation:** captured word layouts, scheduling, typing plans, mocked key delivery, partial OS delivery, key release, input acknowledgments, and timeouts are tested without sending keys to any live application. The user confirmed an earlier direct-text build defeats enemies but reported a return to the Gold Saucer. Keyboard-mode typing and prevention of that kick still require live verification.

## Load and use

Build with `dotnet build KeyboundHelper.csproj -c Release` using .NET 10 and an installed Dalamud API 15 SDK. Add `bin/Release/KeyboundHelper.dll` to Dalamud's Dev Plugin Locations. If an older build is loaded, reload the plugin after building.

1. Enter a Keybound round and open `/keybound`.
2. Choose whether to **Type in lowercase**; uncheck it to preserve the displayed capitalization.
3. Adjust **Between words (ms)** or expand **Timing and retries** as needed. The built-in mapping and keyboard input are always active.
4. Click **Start** to keep submitting. Start can be queued during a typing lockout; submission waits until the input is enabled.
5. Stop with **F8**, `/keybound stop`, or the Stop button.

Default base between-word interval: 800 ms, in addition to character typing and the pause before Enter. An unchanged word can be retried after 2.5 seconds, at most three submissions per slot/word, including visibility flashes. Untried visible slots take priority, then the least recently submitted eligible slot. If no eligible work remains and retries are exhausted, the helper waits for new words. There is no verified distance or HP prioritization. The counter measures submission attempts, not confirmed hits.

The helper pauses when typing is disabled, the game lacks focus, or the input contains existing text. It waits through temporary missing interfaces between waves. It stops typing when the observed layout changes, you leave the territory, log out, enter PvP, or an unrecoverable operation fails. Optional auto-activate and requeue behavior is described above; F8/Stop suspends both for the session.

## Diagnostics

Enable **Show debugging** for **Capture interfaces**, **Export capture**, **Copy diagnostics**, **Submit one word**, and the live-word/interface views. The export path is shown and copied to the clipboard. These local captures can include chat/player names; nothing is uploaded automatically.

The interface viewer is read-only. The built-in profile supports the territory and English word-label layout observed in the supplied captures; other layouts require evidence before adding support.

## Implementation and tests

Native UI reads and typing progression occur on the framework update. Traversal is bounded; paths validate both list position and node ID. All twenty expected word nodes and the expected input type must match. Native pointers are resolved afresh, and the target word and input are checked before sending each key. Key-up cleanup runs even when the ordinary UI-read interval has not elapsed. Only the legacy direct-text mode invokes `InputCallbackType.Enter` directly. Only legacy direct-text mode uses `SetText` for cleanup; keyboard mode uses acknowledged Backspace presses. Existing user text is never deliberately overwritten. Compatibility still depends on the installed FFXIVClientStructs version.

Run `dotnet run --project ../KeyboundHelper.Tests -c Release`. Tests replay the original three captures plus ten distinct wave/boss captures and check word filtering, multiword/punctuation preservation, lockout and recovery, changed/missing layouts, input contents, hidden stale labels, scheduling, and retry limits. Fixtures include only `KTGEWord` and `KTGInput`; unrelated captured chat and player names are excluded.

Sources: [FFXIVClientStructs text input](https://github.com/aers/FFXIVClientStructs/blob/main/FFXIVClientStructs/FFXIV/Component/GUI/AtkComponentTextInput.cs), [input callbacks](https://github.com/aers/FFXIVClientStructs/blob/main/FFXIVClientStructs/FFXIV/Component/GUI/AtkComponentInputBase.cs), [Windows SendInput](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput), [scan-code and Unicode input](https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-keybdinput), [keyboard layout mapping](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-vkkeyscanexw).


