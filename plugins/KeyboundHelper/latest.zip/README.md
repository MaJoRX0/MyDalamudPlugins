# Keybound Helper

Human-like pacing for Keybound Brawler. Open `/keybound`.

## Version 0.2.3

Direct submission is enabled by default. It waits for the configured typing and submission duration, then calls the game's word action for the selected enemy. It does not type visible letters, send Windows keyboard events, focus the input bar, or require the game window to be foreground. Lowercase applies only to keyboard mode. Typo chance works in both modes: keyboard mode submits a misspelled word, while direct mode spends the preparation time and skips the attack. A simulated miss does not count as a successful submission or use up the no-progress attack budget.

The previous character-by-character keyboard mode remains available by disabling **Direct submission**. It requires game focus and retains its acknowledged key delivery, accented characters, optional lowercase, occasional errors, and Ctrl+A/Backspace recovery. Changing input modes stops the current run; press Start again.

### Targets and priorities

The **Targets** table shows every eligible native enemy word (concealed labels are marked **hidden**), its player-to-enemy distance, barrier/casting/interrupt status, and cast progress. Distance uses the game's native word-to-entity map and world coordinates, replacing screen-position guesses when native data is valid. A blank distance means unavailable, not zero.

With **Prioritize barriers and casts** enabled, selection ranks barriers first, interruptible casts with positive remaining-hit counts second, other casts third, and ordinary enemies last. More advanced casts win within the two casting groups. Cast bars are associated by proximity to phrase labels, preferring enemies that native data identifies as casting; ambiguous overlaps and duplicate phrases do not receive a guessed interrupt counter. Geometry-free legacy captures retain the older observed slot association for replay. Hidden retained label text is usable only when it matches a live native enemy. Known cast associations survive concealment; fresh counters still update, and a hidden counter retains its last-known requirement only while native data confirms the same cast. Explicit interruption, observed zero, a changed/restarted cast, a changed phrase, or a dead/missing entity invalidates old priority. A missing counter never counts as evidence of attack progress.

Choose **Closest**, **Shortest**, or **Smart** within those priority groups. Smart uses closest below the **Crowded at** threshold and shortest at or above it (default four eligible live targets, including concealed enemies). The selected word finishes its delay even when its label becomes hidden. Before submission, the entity, both original phrases, round, and death state are rechecked. A killed or replaced target cancels immediately, including during a lockout. A valid native enemy remains selectable while its label is concealed. Smart counts native enemies rather than rendered labels, so visibility flashes do not switch its closest/shortest strategy. Keyboard mode also uses native-validated word bindings when available; without valid native data its conservative UI fallback remains unchanged.

**Typing speed (WPM)** is the sole timing control, ranging from 20 to 300 with a default of 60. A standardized word is five characters. WPM sets the modeled typing pace; recognition, submission pauses, game waits, and keyboard acknowledgment overhead add time, so effective match throughput will be lower. Old millisecond/variation settings are ignored on upgrade, and existing typo chance is preserved.

The model uses two lognormal timing components (fluent typing and occasional hesitation), correlated pace across words, and conventional QWERTY letter-pair adjustments. Recognition, before-submit and between-word delays scale with WPM automatically. Timing changes apply to the next word, including after lockout; an existing plan retains its chosen timing. Unicode text elements remain intact. The structure is informed by [copy-typing mixture-model research](https://link.springer.com/article/10.1007/s11145-021-10203-z) and [Aalto's 136-million-keystroke study](https://userinterfaces.aalto.fi/136Mkeystrokes/). The coefficients are bounded engineering defaults, not parameters fitted to those datasets or a guarantee of indistinguishable human behavior.

**Typo chance (%)** ranges from 0 to 50 and is a per-eligible-word probability, including retries. There is no twelve-clean-word spacing rule or hidden 5% cap. Zero disables intentional mistakes. A typo changes one ASCII letter, preserves its case, and is rejected if it would match another candidate word. Non-ASCII-only words remain accurate, and the one-word diagnostic test never intentionally misses. Therefore the overall observed rate can be lower than the setting when words are ineligible or actions are cancelled. The default remains 3%.

The per-target retry delay still applies. In direct mode, **Attempts without progress** temporarily cools an unchanged target for eight seconds; falling HP or interrupt counts reset that budget. Empty waves wait for new enemies. A successful native return increments the submission counter; it is not proof of enemy damage.


### Hidden-word fix

Version 0.2.2 separates rendered visibility from target eligibility. The earlier version dropped concealed enemies from selection and Smart's crowd count, could transfer their cast bar to a nearby visible enemy, and treated a missing counter as a reduction to zero. The tracker now follows exact native entity and phrase identities across frames and clears its memory at round boundaries, invalid native reads, and Stop. Existing plans still finish without restarting just because the word disappears. Current entity/death/phrase checks remain in place before native submission.

Saucy's source was refreshed on 2026-10-29 and remains at commit ec18e30: its selection reads the native word map without a rendered-visibility gate. AutoKeyboundBrawler's repository returned “not found” when refreshing, so its previously downloaded 863e753 snapshot was used: it reads hidden text or remembered phrases while the obscuring overlay is visible, then links them to native enemies. Our implementation uses native identity validation rather than copying its UI memory implementation.

New checks alternate hidden/visible labels, blank or temporarily missing word interfaces, hidden cast counters, all sixteen visibility combinations around Smart's crowd threshold, teammate kills, reused slots, cast changes, memory reset, and the original flashing-boss captures. These checks simulate native enemy data; the updated behavior still needs an in-game concealment test.

### Letterlock and inactivity

The helper waits near completion of the three known Letterlock-related casts (49529, 49532, 49702), through their three-second post-cast guard, while Watched status 5346 is present, or while the visible typing input is disabled. It resumes remaining preparation time afterward and abandons targets that disappeared. The keyboard fallback uses its existing lockout recovery, including pending-key reconciliation.

While automatic submission is running in a validated, active Keybound round, each framework update resets:

- Keybound's own input-agent inactivity counter.
- General AFK, input, and content/duty input timers.
- Every controller input timer and mouse input timer exposed by the SDK.

These are the timer resets found across the two reference plugins. The shared Keybound timer is reset once per update, rather than separately on Saucy's 20-second schedule. Stop, F8 while the game is focused, unload, leaving the fight, and round completion end these resets. There are no global background key presses. The undocumented timer that AutoKeyboundBrawler only logs is not modified.

### Reward statistics

The main window shows **Session** and **Lifetime** MGP/MGC rewards. Session totals count results observed while Auto-requeue is enabled, reset on off-to-on activation or plugin reload, and remain visible after disabling requeue if rewards were earned. Stop/Resume and a temporary pause keep the current session. Lifetime totals count all observed Keybound results, including manual rounds, and are saved in the plugin configuration after each recorded round. They are earned-reward totals, not the current wallet balance, and cover this plugin configuration rather than separate character accounts.

The supplied 2026-10-29 result capture verifies **2,588 MGP** at `KTGResult[1]/16:36/6:2/1:2` and **326 MGC** at `15:37/6:2/1:2`. The reader also validates the Keybound title, Exit label, and Reward heading. Values must be visible, uniquely mapped, nonnegative integers with valid comma grouping. The capture is a test fixture; historical earnings are not automatically imported.

Both amounts must stay unchanged for 600 ms before collection. Each result is counted once, with a persisted guard against a plugin reload on the same result screen. A lobby transition or a sustained new active fight rearms collection, so identical rewards in another round still count. Missing or briefly hidden result UI does not rearm the guard. Tracking continues when the helper window is closed or typing/requeue is paused. Auto-exit waits for collection, with a five-second fallback if the reward fields cannot be read; unread rewards leave totals unchanged and are reported under Show debugging.

Tests replay the sanitized capture, check both session/lifetime amounts, persistence and duplicate prevention, repeated equal rewards in later rounds, changes while amounts settle, disabled requeue, missing/duplicate fields, zero rewards, and numeric overflow. The 300 WPM ceiling is checked in configuration normalization and sampled timing plans. Frame pacing, key acknowledgments and game waits still limit achieved throughput.

### Auto-activate and requeue

Both are optional. Requeue first requires observing a manually entered fight in this session. It exits the results, interacts with the nearby Keybound registrar without movement, registers, waits for the matching duty pop, and commences. Auto-activate starts submission when the next fight becomes ready. In direct mode these actions do not require game focus; keyboard mode retains its foreground checks. Stop suspends both until Start or Resume automation.

### Load and test

Build with .NET 10 and the installed Dalamud API 15 SDK:

`dotnet build KeyboundHelper/KeyboundHelper.csproj -c Release --no-restore`

DLL: `KeyboundHelper/bin/Release/KeyboundHelper.dll`

Packaged release: `KeyboundHelper/bin/Release/KeyboundHelper/latest.zip`

Reload the plugin in Dalamud, enter a round, open `/keybound`, and press Start. **Show debugging** exposes a one-word test, native-read/reset status, diagnostics, interface captures, and five-second position recordings. Captures remain local and may include player-name labels.

**Validation:** the console suite has 1169 passing checks covering recorded UI frames, keyboard delivery/recovery, target ranking, spatial cast association, duplicate phrases, dead targets, hidden-word continuation, wave gaps, retry budgets, WPM scaling, settings migration, typo rates, direct-mode missed attacks, and Letterlock guards. Simulations produced 0/10,000 typos at 0%, 290/10,000 at 3%, and 4,950/10,000 at 50%. It runs without sending live keys or invoking game actions. Run it with `dotnet run --project KeyboundHelper.Tests -c Release --no-restore`.

The new native word action, live memory layout, inactivity writes, and unfocused requeue still require in-game validation. Check one submission first, then a round lasting over 60 seconds while another window is focused, followed by Letterlock and a complete exit/requeue cycle. Native reads are bounded and validated; unavailable layouts/actions stop direct submission rather than silently switching to keyboard input. Game updates can require new signatures or layouts.

### Research and attribution

Reviewed source snapshots:

- [AutoKeyboundBrawler, commit 863e753](https://github.com/XeldarAlz/FFXIV-AutoKeyboundBrawler/tree/863e7532421bfd8460fdd903d71016b87a878edd): researched target priorities, UI cast detection, direct/typed input behavior, and inactivity reset coverage. Its source is not incorporated into this distribution; target selection and UI association here are independently implemented and differ in ambiguity handling, retry policy, and continuation.
- [Saucy, commit ec18e30](https://github.com/PunishXIV/Saucy/blob/ec18e30459c1ad3b1a42fec53fc2e1e99471043d/Saucy/Games/KeyboundBrawler/KeyboundBrawlerAutomation.cs): native word-action signature, HUD target layout, input-agent inactivity counter, and Letterlock action timing. The adapter includes additional bounded reads and identity validation. Saucy is distributed under the BSD 3-Clause license reproduced below.
- [FFXIVClientStructs](https://github.com/aers/FFXIVClientStructs): installed SDK definitions for objects, casts, agents, text input, and input timers.

### Saucy license

BSD 3-Clause License

Copyright (c) 2023, Puni.sh

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
