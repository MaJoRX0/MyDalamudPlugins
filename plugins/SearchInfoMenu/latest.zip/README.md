# SearchInfoMenu

Adds the game's native View Search Info action to player right-click context menus.

It opens the existing SocialDetail/Search Info window directly for visible players, without making you open Player Search first or recreating the window in plugin UI.

Right-click another visible player and choose `View Search Info`.
