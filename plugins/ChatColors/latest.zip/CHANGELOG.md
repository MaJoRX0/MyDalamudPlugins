# Chat Colors Changelog

## 0.1.1.0 - 2026-08-29
- Renamed the plugin metadata to Chat Colors.
- Added local-only ChatTwo display coloring for Echo messages using `<0>` to `<77>`, `<500>` to `<521>`, and `<reset>`.
- Removed Harmony patching and switched to editing ChatTwo's local display message list.
- Kept compatibility with original ChatTwo and the modified ChatTwo build by supporting both color member spellings.
- Reduced profiler cost by waking only after tagged Echo messages and checking only the newest visible messages.
